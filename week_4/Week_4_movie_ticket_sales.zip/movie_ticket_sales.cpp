#include <iostream>
#include <iomanip>
#include <limits>
#include <string>
using namespace std;

int customers;
int ticketQuantity;
int category;
double ticketPrice;
double transactionTotal;
string categoryName;

int main()
{
 char anotherSession = 'Y';
 cout << fixed << setprecision(2);
 
 // Repeat sales sessions
while (anotherSession == 'Y' || anotherSession == 'y')
{
 int totalTickets = 0;
 double totalRevenue = 0.0;
 int childTickets = 0;
 int adultTickets = 0;
 int seniorTickets = 0;
 double averageTransaction;

 cout << "Enter the number of customers (1-50): ";
 cin >> customers;

// Validate customer input
while (cin.fail() || customers < 1 || customers > 50)
{
    if (cin.fail())
    {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    cout << "Invalid number. Please enter a value between 1 and 50: ";
    cin >> customers;
}

cout << "Customers: " << customers << endl;

 //Process each customer
 for (int i = 1; i <= customers; i++)
 {
    cout << "\nCustomer " << i << endl;
  
    cout << "How many tickets would you like to purchase (1-10)? ";
    cin >> ticketQuantity;
    
    //Validate ticket quantity
  while (cin.fail() || ticketQuantity < 1 || ticketQuantity > 10)
{
    if (cin.fail())
    {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    cout << "Invalid quantity. Please enter 1-10: ";
    cin >> ticketQuantity;
}
 

    cout << "\nSelect Ticket Category" <<endl;
    cout << "1. Child - $8.00" << endl;
    cout << "2. Adult - $12.00" << endl;
    cout << "3. Senior - $9.00" << endl;
    
    cout << "Enter your selection: ";
    cin >> category;

    // Validate category
    while (cin.fail() || category < 1 || category > 3)
{
    if (cin.fail())
    {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    cout << "Invalid selection. Please choose 1, 2, or 3: ";
    cin >> category;
}
      if (category == 1)
      {
         ticketPrice = 8.00;
         categoryName = "Child";
         childTickets += ticketQuantity;
      }
       else if (category == 2)
       {
         ticketPrice = 12.00;
         categoryName = "Adult";
         adultTickets += ticketQuantity;
       }
       else
       {
         ticketPrice = 9.00;
         categoryName = "Senior";
         seniorTickets += ticketQuantity;
       }
        
       transactionTotal = ticketQuantity * ticketPrice;
       totalTickets += ticketQuantity;
       totalRevenue += transactionTotal;
       
cout << "Tickets Purchased: " << ticketQuantity << endl;
cout << "Ticket Category: " << categoryName << endl;
cout << "Price Per Ticket: $" << ticketPrice << endl;
cout << "Transaction Total: $" << transactionTotal << endl; 

 }

cout << "\n========================================" << endl;
cout << "       MOVIE THEATER SALES REPORT" << endl;
cout << "========================================" << endl;
cout << "Customers Processed: " << customers << endl;



cout << "\nChild Tickets Sold: " << childTickets << endl;
cout << "Adult Tickets Sold: " << adultTickets << endl;
cout << "Senior Tickets Sold: " << seniorTickets << endl;

averageTransaction = totalRevenue / customers;

cout << "Total Tickets Sold: " << totalTickets << endl;
cout << "Total Revenue: $" << totalRevenue << endl;

cout << "Average Transaction: $" << averageTransaction << endl;
cout << "========================================" << endl;

cout << "\nWould you like to process another sales session?" << endl;
cout << "Enter Y for Yes or N for No: ";
cin >> anotherSession;

// Validate session choice
while (anotherSession != 'Y' && anotherSession != 'y' &&
       anotherSession != 'N' && anotherSession != 'n')
{
    cout << "Invalid choice. Please enter Y or N: ";
    cin >> anotherSession;
}

} // End of sales session while loop

cout << "\nThank you for using the Movie Theater Ticket Sales System!" << endl;


return 0;
}
